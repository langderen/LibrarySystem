<template>
  <div id="app-container">
    <!-- 顶部导航栏 -->
    <!-- 使用 Flexbox 布局替代 float 和 text-align -->
    <el-header style="display: flex; align-items: center; padding: 0 20px;">
      <!-- 左侧 Logo -->
      <div style="font-size: 20px; font-weight: bold; color: #409EFF;">
        图书管理系统
      </div>

      <!-- 右侧区域：导航和用户信息 -->
      <div style="display: flex; align-items: center; margin-left: auto;">
        <!-- 导航菜单 -->
        <el-menu
          :default-active="route.path"
          class="el-menu-demo"
          mode="horizontal"
          background-color="transparent"
        >
          <!-- 使用 to 属性进行路由跳转，更简洁 -->
          <el-menu-item index="/" @click="goTo('/')">首页</el-menu-item>
        <el-menu-item index="/books" @click="goTo('/books')">图书借阅</el-menu-item>
        </el-menu>

        <!-- 用户信息/登录按钮 -->
        <div style="margin-left: 20px;">
          <!-- 使用 store 的 state 来判断登录状态 -->
          <template v-if="userStore.isFinited">
            <el-dropdown>
              <span class="el-dropdown-link">
                欢迎，{{ userStore.userName }}
              </span>
              <!-- 使用 Vue 3 的 v-slot 指令 -->
              <template #dropdown>
                <el-dropdown-menu>
                  <el-menu-item @click="goTo('/profile')">个人中心</el-menu-item>
                  <el-menu-item @click="handleLogout">退出登录</el-menu-item>
                </el-dropdown-menu>
              </template>
            </el-dropdown>
          </template>
          <router-link v-else @click="goTo('/login')" class="el-button el-button--primary el-button--mini">
            登录
          </router-link>
        </div>
      </div>
    </el-header>

    <!-- 主内容区域 -->
    <el-main>
      <router-view />
    </el-main>

    <!-- 页脚 -->
    <el-footer style="text-align: center">
      <span>© 2025 图书管理系统 | Powered by Vue 3 & Element Plus</span>
    </el-footer>
  </div>
</template>

<script setup>
import { onMounted } from 'vue';
import { useRouter, useRoute } from 'vue-router';
// 【修正】正确导入 useUserStore 函数
import { useUserStore } from '@/stores/user';
import apiService from './service/api';

const router = useRouter();
const route = useRoute(); // 【修正】获取当前路由对象
// 【修正】正确获取 store 实例
const userStore = useUserStore();

const goTo = (path) => {
  router.push(path);
};

// 【修正】调用 store 的 action 来处理退出登录
const handleLogout = () => {
  userStore.clearUser();
  router.push('/login');
};

// 【修正】在 onMounted 中调用 store 的 action 来初始化状态
onMounted(() => {
});
</script>

<style scoped>
#app-container {
  display: flex;
  flex-direction: column;
  height: 100vh;
}
.el-header, .el-footer {
  background-color: #fff;
  color: #333;
  line-height: 60px;
  border-bottom: 1px solid #ebeef5;
}
.el-main {
  flex: 1;
  padding: 20px;
  overflow-y: auto;
  background-color: #f9fafc;
}
.el-menu-demo:not(.el-menu--collapse) {
  border-bottom: none;
}
.el-dropdown-link {
  cursor: pointer;
}
</style>