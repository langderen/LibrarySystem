import { createApp } from 'vue'
import { createPinia } from 'pinia'
import piniaPluginPersistedstate from 'pinia-plugin-persistedstate';
import App from './App.vue'
import VueCookies from 'vue3-cookies'
import 'element-plus/dist/index.css'
import ElementPlus from 'element-plus'
import router from './router';

// 1. 创建应用实例
const app = createApp(App)

// 2. 创建并配置 Pinia
const pinia = createPinia()
pinia.use(piniaPluginPersistedstate)
app.use(pinia)

// 3. 注册其他插件
app.use(router)
app.use(ElementPlus)

// 4. 注册 vue3-cookies 并配置默认选项 (推荐)
app.use(VueCookies, {
  expireTimes: "7d", // 设置默认过期时间为7天
  path: "/",        // 设置默认路径为根路径
  domain: "",       // 设置默认域名
  secure: true,     // 设置默认是否为安全cookie
  sameSite: "None"  // 设置默认SameSite属性
})

// 5. 挂载应用
app.mount('#app')